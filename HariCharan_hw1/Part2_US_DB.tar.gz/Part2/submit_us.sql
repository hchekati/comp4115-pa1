-- MySQL dump 10.13  Distrib 5.6.22, for osx10.8 (x86_64)
--
-- Host: localhost    Database: us_states
-- ------------------------------------------------------
-- Server version	5.6.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `State_Name` varchar(20) DEFAULT NULL,
  `Population` int(11) DEFAULT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Capital` varchar(15) DEFAULT NULL,
  `Crime_Rate` enum('high','low') DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES ('Tennesse',6549352,1,'Nashville','high'),('Kentucky',4413457,2,'Frankfort','low'),('NorthCarolina',9943964,3,'Raleigh','low'),('Mississippi',2994079,4,'Jackson','high'),('Alabama',4849377,5,'Birmingham','high'),('Illinois',12880580,6,'Chicago','low'),('California',38802500,7,'Sacramento','high'),('Florida',19893297,8,'Tallahassee','high'),('NewYork',19746227,9,'NewYorkCity','high'),('Georgia',10097343,10,'Atlanta','low'),('Alaska',670035,14,'Juneau','high'),('Arizona',6392017,21,'Phoenix','low'),('Arkansas',2915918,22,'LittleRock','high'),('Colorado',5029196,26,'Denver','low'),('Connecticut',3574097,27,'Hartfort','high'),('Delaware',897934,28,'Dover','high'),('Hawaii',1211537,31,'Honolulu','low'),('Idaho',1567582,32,'Boise','high'),('Indiana',6080485,33,'Indianapolis',NULL),('Iowa',3046355,34,'DesMoines','high'),('Kansas',2853118,35,'Topeka','low'),('Louisiana',4533372,36,'BantonRouge','high'),('Maine',1274923,37,'Augusta','low'),('Maryland',5600388,38,'Annapolis','high'),('Massachusetts',6349097,39,'Boston','low'),('Michigan',9883640,40,'Lansing','low'),('Minnesota',5132799,41,'SaintPaul','high'),('Missouri',5595211,42,'JeffersonCity','high'),('Montana',989415,43,'Helena','low'),('Nebraska',1711263,44,'Lincoln','high'),('Nevada',1988258,45,'CarsonCity','low'),('NewHampshire',1235786,46,'Concord','high'),('NewJersey',8414350,47,'Trenton','low'),('NewMexico',1928384,48,'SantaFe','low'),('NorthDakota',642200,49,'Bismarck','high'),('Ohio',11536504,50,'Columbas','high'),('Oklahoma',3751351,51,'OklahomaCity','low'),('Oregon',3831073,52,'Salem','high'),('Pennsylvania',12702379,53,'Harrisburg','high'),('RhodeIsland',1048319,54,'Providence','low'),('SouthCarolina',462536,55,'Charleston','low'),('SouthDakota',754844,56,'Pierre','high'),('Texas',27000000,57,'Austin','high'),('Utah',2763885,58,'SaltlakeCity','low'),('Vermont',625741,59,'Montpelier','high'),('Virginia',7567465,60,'Richmond','high'),('Washington',6724540,61,'Olympia','low'),('WestVirginia',1808344,62,'Charleston','high'),('Wisconsin',5627967,63,'Madison','low'),('Wyoming',563626,64,'Cheyenne','low');
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-12 15:34:40
